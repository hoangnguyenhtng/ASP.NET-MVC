﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using VuTheNguyen_211201947.Models;

namespace VuTheNguyen_211201947.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            QLHangHoaContext db = new QLHangHoaContext();
            var hanghoa = db.HangHoas.Where(p => p.Gia >= 100).ToList();
            return View(hanghoa);
        }
        public IActionResult HangHoaTheoLoai(int? maloaihang)
        {
            QLHangHoaContext db = new QLHangHoaContext();
            var hanghoa = db.HangHoas.Where(p => p.MaLoai == maloaihang).ToList();
            return PartialView("MatHang", hanghoa);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(TblAccount user)
        {
            QLHangHoaContext db = new QLHangHoaContext();
            if (ModelState.IsValid)
            {
                var data = db.TblAccounts.Where(a => a.Username.Equals(user.Username) && a.Password.Equals(user.Password)).FirstOrDefault();
                if (data != null)
                {
                    HttpContext.Session.SetString("UserId", data.Uid.ToString());
                    HttpContext.Session.SetString("UserName", data.Username);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    return View(user);
                }
            }
            return View(user);
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Rehgister(TblAccount user)
        {
            QLHangHoaContext db = new QLHangHoaContext();
            if (ModelState.IsValid)
            {
                var ac = db.TblAccounts.FirstOrDefault(a => a.Username ==  user.Username);  
                if(ac == null)
                {
                    db.TblAccounts.Add(user);
                    await db.SaveChangesAsync();
                    return RedirectToAction("Login", "Home");
                }
                else
                {
                    ViewBag.error = "User Already exist";
                    return View(user);
                }
            }
            return View(user);
        }
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Home");
        }
    }
}